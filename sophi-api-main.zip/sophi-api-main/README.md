# sophi-api
implementação de uma REST API usando alguns projetos do ecossistema Spring, como Spring Boot e Spring Data JPA. Uma API construída com ajuda do professor da AlgaWorks. https://youtu.be/9GWK9A79tEc
